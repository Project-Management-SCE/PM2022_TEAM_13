<?php 

header('Content-Type: application/json');

require_once 'core/init.php';
require_once 'connectionoop.php';



$data = array(
  "users"=>array(),
  "assos"=>array()
);
$query2 = sprintf("SELECT * FROM users WHERE 1");
$result = $mysqli->query($query2);

foreach ($result as $row) {
  $data['users'][] = $row;
}

$query2 = sprintf("SELECT * FROM association WHERE 1");
$result = $mysqli->query($query2);

foreach ($result as $row) {
  $data['assos'][] = $row;
}

$result->close();
//close connection
$mysqli->close();

//now print the data
print json_encode($data);


?>