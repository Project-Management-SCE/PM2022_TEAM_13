
function updateusers(id){
	var btn = document.getElementById('usersbtn'+id);
	btn.style.display="none";
	var str ='usersForm'+id;
	var f = document.forms[str];
	for(var i=0,fLen=f.length;i<fLen;i++){
	  f.elements[i].readOnly = false;//As @oldergod noted, the "O" must be upper case
	  f.elements[i].style.backgroundColor="white";
	}
	f.elements[0].style.display="block";
	f.elements[0].style.backgroundColor="#7b97ea";
	btn = document.getElementById('userscancel'+id);
	btn.style.display="block";
	var td =document.getElementById('joined'+id);
	td.type='date';
	

	}


function CancelUsers(id){
	var btn = document.getElementById('usersbtn'+id);
	btn.style.display="block";
	var str ='usersForm'+id;
	var f = document.forms[str];
	for(var i=0,fLen=f.length;i<fLen;i++){
	  f.elements[i].readOnly = true;//As @oldergod noted, the "O" must be upper case
	  f.elements[i].style.backgroundColor="#7b97ea";
	}
	f.elements[0].style.display="none";

	btn = document.getElementById('userscancel'+id);
	btn.style.display="none";
	var td =document.getElementById('joined'+id);
	td.type='text';
	

}


function updateAssos(id){
	var btn = document.getElementById('assosbtn'+id);
	btn.style.display="none";
	var str ='assosForm'+id;
	var f = document.forms[str];
	for(var i=0,fLen=f.length;i<fLen;i++){
	  f.elements[i].readOnly = false;//As @oldergod noted, the "O" must be upper case
	  f.elements[i].style.backgroundColor="white";
	}
	// f.elements[0].style.display="block";
	// f.elements[0].style.backgroundColor="#7b97ea";
	var sub = document.getElementById('Rsub'+id);
	sub.style.display="block";
	sub.style.backgroundColor="#7b97ea";


	btn = document.getElementById('assoscancel'+id);
	btn.style.display="block";

	var td =document.getElementById('TargetStart'+id);
	td.type='date';
	td=document.getElementById('TargetEnd'+id);
	td.type='date';



	}


function CancelAssos(id){
	var btn = document.getElementById('assosbtn'+id);
	btn.style.display="block";
	var str ='assosForm'+id;
	var f = document.forms[str];
	for(var i=0,fLen=f.length;i<fLen;i++){
	  f.elements[i].readOnly = true;//As @oldergod noted, the "O" must be upper case
	  f.elements[i].style.backgroundColor="#7b97ea";
	}
	var sub = document.getElementById('Rsub'+id);
	sub.style.display="none";
	

	btn = document.getElementById('assoscancel'+id);
	btn.style.display="none";

	var td =document.getElementById('TargetStart'+id);
	td.type='text';
	td=document.getElementById('TargetEnd'+id);
	td.type='text';

}

function Deleteusers(id) {
  if(id==" "){
    console.log(";a;a;a");
    return;
	}
	else{
 el=document.getElementById('id01');
 el.parentNode.removeChild(el);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert("user  deleted please refresh the page")
    }
  };
 
  xhttp.open("GET", "UserDelete.php?id="+id, true);
  xhttp.send();
  }
  
}
function DeleteAssos(id) {
  if(id==" "){
    console.log(";a;a;a");
    return;
	}
	else{
 el=document.getElementById('id02');
 el.parentNode.removeChild(el);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert("user  deleted please refresh the page")
    }
  };
 
  xhttp.open("GET", "AssosDelete.php?id="+id, true);
  xhttp.send();
  }
  
}




function buildTable2(data){
	let table = document.getElementById('myTable')
		
		for (var i = 0; i < data.users.length; i++){

			var date =new Date(data.users[i].joined)
			var d = date.getDate();
			var m = date.getMonth() + 1;
			var y = date.getFullYear();

			var dateString =y+ '-' + (m <= 9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d) ;
			var row = `<form id = "usersForm${data.users[i].id}" action="updateUsers.php?id=${data.users[i].id}" method="post"><tr>
							<td>
							<button id="usersdelbtn${data.users[i].id}" onclick="document.getElementById('id01').style.display='block';document.getElementById('btn1').value=this.value" value="${data.users[i].id}">הסר משתמש</button>
							</td>
							<td>
							<button style="display:none;float:right;" id="userscancel${data.users[i].id}" onclick="CancelUsers(this.value)" value="${data.users[i].id}">X</button>
							 <input style="display:none;" type="submit" name="sub${data.users[i].id}" id ="sub${data.users[i].id}" value="עדכן משתמש" form="usersForm${data.users[i].id}" >
							<button id="usersbtn${data.users[i].id}" onclick="updateusers(this.value)" value="${data.users[i].id}"> עריכה</button>
							</td>
							<td><input type="text" name="email${data.users[i].id}" id="email${data.users[i].id}" value="${data.users[i].email}" autocomplete="off"  readonly  form="usersForm${data.users[i].id}"></td>
							<td><input type="text" name="joined${data.users[i].id}" id="joined${data.users[i].id}" value="${dateString}" autocomplete="off"  readonly  form="usersForm${data.users[i].id}">
							<input type="hidden" name="id${data.users[i].id}" id="id${data.users[i].id}" value="${data.users[i].id}" autocomplete="off" readonly form="usersForm${data.users[i].id}"></td>
							<td><input type="text" name="last_name${data.users[i].id}" id="last_name${data.users[i].id}" value="${data.users[i].last_name}" autocomplete="off" readonly form="usersForm${data.users[i].id}"></td>
							<td><input type="text" name="first_name${data.users[i].id}" id="first_name${data.users[i].id}" value="${data.users[i].first_name}" autocomplete="off" readonly form="usersForm${data.users[i].id}"></td>
							<td ><input type="text" name="username${data.users[i].id}" id="username${data.users[i].id}" value="${data.users[i].username}" autocomplete="off" readonly form="usersForm${data.users[i].id}"></td>
							
					  </tr>
					  </form>`
		
					  table.innerHTML+=row
			}
	

			table = document.getElementById('myTable2')
		for (var i = 0; i < data.assos.length; i++){
				
			var row = `
							<form id = "assosForm${data.assos[i].id}" action="updateAssos.php?id=${data.assos[i].id}" method="post">
							<tr>
							<td>
							<button id="assosdelbtn${data.users[i].id}" onclick="document.getElementById('id02').style.display='block';document.getElementById('btn2').value=this.value" value="${data.assos[i].id}">הסר עמותה</button>
							</td>
							<td>
							<button style="display:none;float:right;" id="assoscancel${data.assos[i].id}" onclick="CancelAssos(this.value)" value="${data.assos[i].id}">X</button>
							<input style="display:none;" name="Rsub${data.assos[i].id}" id ="Rsub${data.assos[i].id}" type="submit" value="עדכן עמותה" form="assosForm${data.assos[i].id}">
							<button id="assosbtn${data.assos[i].id}" onclick="updateAssos(this.value)"  value="${data.assos[i].id}">עריכה</button>

							</td>
							<td><input type="text" name="TargetEnd${data.assos[i].id}" id="TargetEnd${data.assos[i].id}" value="${data.assos[i].TargetEnd}"autocomplete="off" readonly form="assosForm${data.assos[i].id}"></td>
							<td><input type="text" name="TargetStart${data.assos[i].id}" id="TargetStart${data.assos[i].id}" value="${data.assos[i].TargetStart}"autocomplete="off" readonly form="assosForm${data.assos[i].id}"></td>
							<td><input type="text" name="mobileContact${data.assos[i].id}" id="mobileContact${data.assos[i].id}" value="${data.assos[i].mobileContact}" autocomplete="off" readonly form="assosForm${data.assos[i].id}"></td>
							<td><input type="text" name="Anumber${data.assos[i].id}" id="Anumber${data.assos[i].id}" value="${data.assos[i].Anumber}" autocomplete="off" readonly form="assosForm${data.assos[i].id}"></td>
							<td><input type="text" name="Aname${data.assos[i].id}" id="Aname${data.assos[i].id}" value="${data.assos[i].Aname}" autocomplete="off" readonly form="assosForm${data.assos[i].id}"></td>

							
							
					  </tr>
					  </form>`
		
					  table.innerHTML+=row
		}





}
		
		

	

		

		
		
		
	
	

document.addEventListener("DOMContentLoaded", getUsers);

function getUsers() {

var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        data3 = JSON.parse(this.responseText);
		console.log(data3)
		

		el = document.getElementById("myTableHead");
		//If it isn't "undefined" and it isn't "null", then it exists.
    if(typeof(el) != 'undefined' && el != null){
        el.parentNode.removeChild(el);
    } 	

		el = document.getElementById("myTableHead2");
		//If it isn't "undefined" and it isn't "null", then it exists.
    if(typeof(el) != 'undefined' && el != null){
        el.parentNode.removeChild(el);
    } 	
		
		let table2 = document.createElement('table');
		table2.id="myTableHead2";
		   
		let table = document.createElement('table');
		table.id="myTableHead";
		

		let row1 = document.createElement('div');
		row1.innerHTML+="<h1 align ='center' style='color : blue';font-size:'5vw'>משתמשים</h1>";
		row1.style.margin="auto";
		row1.style.display="block";

		document.getElementById('main').appendChild(row1);


		// Adding the entire table to the body tag
		document.getElementById('main').appendChild(table);


		let row2 = document.createElement('div');
		row2.style.margin="auto";
		row1.style.display="block";
		row2.innerHTML+="<h1 align ='center' style='color:blue';font-size:'5vw'>עמותות</h1>";

		document.getElementById('main').appendChild(row2);
		


		document.getElementById('main').appendChild(table2);


		

		let row_1 = document.createElement('tr');

		row_1.id ="Mrow_1";
		row_1.className ="bg-info";

		let heading_0 = document.createElement('th');
		heading_0.innerHTML = "";
		let heading_01 = document.createElement('th');
		heading_01.innerHTML = "אימייל";
		let heading_1 = document.createElement('th');
		heading_1.innerHTML = "תאריך הצטרפות";
		let heading_2 = document.createElement('th');
		heading_2.innerHTML = "שם משפחה";
		let heading_3 = document.createElement('th');
		heading_3.innerHTML = "שם פרטי";
		let heading_4 = document.createElement('th');
		heading_4.innerHTML = "שם משתמש";
		let heading_5 = document.createElement('th');
		heading_5.innerHTML = "";

		row_1.appendChild(heading_5);
		row_1.appendChild(heading_0);
		row_1.appendChild(heading_01);
		row_1.appendChild(heading_1);
		row_1.appendChild(heading_2);
		row_1.appendChild(heading_3);
		row_1.appendChild(heading_4);
		
		table.appendChild(row_1);

		

		let row_2 = document.createElement('tr');

		row_2.id ="Mrow_12";
		row_2.className ="bg-info";



		
		let heading_22 = document.createElement('th');
		heading_22.innerHTML = "תאריך סיום תוכנית";

		let heading_32 = document.createElement('th');
		heading_32.innerHTML = "תאריך תחילת תכנית";
		let heading_42 = document.createElement('th');
		heading_42.innerHTML = "טלפון ליצירת קשר";
		let heading_52 = document.createElement('th');
		heading_52.innerHTML = "מספר עמותה";
		let heading_62 = document.createElement('th');
		heading_62.innerHTML = "שם עמותה";
		let heading_72 = document.createElement('th');
		heading_72.innerHTML = "";
		let heading_73 = document.createElement('th');
		heading_73.innerHTML = "";

		row_2.appendChild(heading_72);
		row_2.appendChild(heading_73);
		row_2.appendChild(heading_22);
		row_2.appendChild(heading_32);
		row_2.appendChild(heading_42);
		row_2.appendChild(heading_52);
		row_2.appendChild(heading_62);
		table2.appendChild(row_2);




		let tbody = document.createElement('tbody');
		tbody.id ="myTable";
		let tbody2 = document.createElement('tbody');
		tbody2.id ="myTable2";

		table.appendChild(tbody);   
		table2.appendChild(tbody2);  

		buildTable2(data3);
		
		
        
    }
};
xmlhttp.open("GET", "getUsersData.php", true);
xmlhttp.send();

}

