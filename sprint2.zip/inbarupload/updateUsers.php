<?php
require_once 'core/init.php';


$id= $_REQUEST['id'];
$user=new User($id);
$userorigin = $user->data()->username;

$sub = 'sub'.$id;
$Rsub='Rsub'.$id;
if(isset($_POST[$sub])){
	$username=$_POST['username'.$id];
	$first_name=$_POST['first_name'.$id];
	$last_name=$_POST['last_name'.$id];
	$joined=$_POST['joined'.$id];
	$email=$_POST['email'.$id];
	
	 


 	$validate =new Validate();
 	if($userorigin==$username){
 		$validation = $validate->check($_POST, array(
		'username'.$id=>array(
			'required'=>true
		),
		'first_name'.$id=>array(
			'required'=>true
		),
		'last_name'.$id=>array(
			'required'=>true
		),
		'joined'.$id=>array(
			'required'=>true
		),
		'email'.$id=>array(
			'required'=>true
		)
	));

 	}
 	else {
 		$validation = $validate->check($_POST, array(
		'username'.$id=>array(
			'required'=>true,
			'unique'=>'users'
		),
		'first_name'.$id=>array(
			'required'=>true
		),
		'last_name'.$id=>array(
			'required'=>true
		),
		'joined'.$id=>array(
			'required'=>true
		),
		'email'.$id=>array(
			'required'=>true
		)
		
	));

 	}
	

	if($validation->passed()){

		try{
			$user->update(array(
				'username' =>$username,
				'first_name' =>$first_name,
				'last_name' =>$last_name,
				'joined' =>$joined,
				'email' =>$email
			),$id);
			
			
			Redirect::to('UsersData.php');
			
		}catch(Exception $e){
			die($e->getMessage());
		}
	}else{
		
		
		foreach($validation->errors() as $error){
			echo '<p align="left">'.$error . '</p>';
		}
		echo '<a href="UsersData.php">חזור לדף הקודם</a>';
	}
	
		
}

  
?>